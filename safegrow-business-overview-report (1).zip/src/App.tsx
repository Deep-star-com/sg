import { useState, useEffect } from "react";
import {
  Shield,
  Globe,
  Star,
  MessageCircle,
  Mail,
  Phone,
  MapPin,
  CheckCircle,
  ChevronDown,
  Menu,
  X,
  Search,
  BarChart3,
  Lock,
  Users,
  ArrowRight,
  Building2,
  Zap,
  Target,
  Award,
  ChevronRight,
  Megaphone,
} from "lucide-react";

const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Pricing", href: "#pricing" },
  { label: "Contact", href: "#contact" },
];

const STATS = [
  { value: "10+", label: "Projects Delivered" },
  { value: "95%", label: "Client Satisfaction" },
  { value: "4", label: "Years Experience" },
  { value: "3", label: "Cities in NCR" },
];

const SERVICES = [
  {
    icon: Globe,
    title: "Website Design & Development",
    description:
      "Fast, mobile-first websites built to convert visitors into calls and bookings. Clear CTAs, service pages, and full contact integration — designed for local businesses.",
    color: "from-blue-500 to-cyan-500",
    bg: "bg-blue-50",
  },
  {
    icon: MapPin,
    title: "Google Business Profile Optimisation",
    description:
      "Complete GBP setup, keyword optimisation, photo uploads, Q&A management, and ongoing posts to maximise your visibility on Google Maps and local search.",
    color: "from-green-500 to-emerald-500",
    bg: "bg-green-50",
  },
  {
    icon: Search,
    title: "Local SEO",
    description:
      "NCR-specific keyword targeting, on-page optimisation, citation building, and structured data markup. Goal: rank page 1 for searches like 'best dentist in Noida.'",
    color: "from-violet-500 to-purple-500",
    bg: "bg-violet-50",
  },
  {
    icon: Users,
    title: "Social Media Management",
    description:
      "Branded content across Instagram and Facebook with a monthly calendar — building trust, showcasing outcomes, and keeping your clinic top-of-mind in your community.",
    color: "from-pink-500 to-rose-500",
    bg: "bg-pink-50",
  },
  {
    icon: Star,
    title: "Review & Reputation Management",
    description:
      "A structured funnel to generate genuine 5-star reviews — automated WhatsApp prompts post-appointment, and active monitoring to catch issues before they escalate.",
    color: "from-yellow-500 to-amber-500",
    bg: "bg-yellow-50",
  },
  {
    icon: MessageCircle,
    title: "WhatsApp & Email Marketing",
    description:
      "Automated sequences that re-engage existing patients, send appointment reminders, share health tips, and drive repeat visits. Reduces churn and increases lifetime value.",
    color: "from-teal-500 to-green-500",
    bg: "bg-teal-50",
  },
  {
    icon: Building2,
    title: "Directory & Platform Listings",
    description:
      "Consistent NAP data submitted and maintained across JustDial, Practo, Sulekha, and 20+ local directories — a strong trust signal for Google's local ranking algorithm.",
    color: "from-orange-500 to-red-500",
    bg: "bg-orange-50",
  },
  {
    icon: Lock,
    title: "Digital Security Basics",
    description:
      "Password audits, Google account security reviews, and cyber hygiene guidance. Protects your GBP, website, and social profiles from account takeover and basic attacks.",
    color: "from-slate-600 to-slate-800",
    bg: "bg-slate-50",
  },
  {
    icon: Megaphone,
    title: "Ad Management",
    description:
      "Targeted Google and Meta ad campaigns designed to drive immediate visibility and patient inquiries. Every rupee tracked, every campaign optimised for your local audience.",
    color: "from-indigo-500 to-blue-600",
    bg: "bg-indigo-50",
  },
];

const CAS_PHASES = [
  {
    phase: "01",
    title: "Audit",
    subtitle: "We map your entire digital footprint first.",
    color: "bg-blue-600",
    textColor: "text-blue-600",
    borderColor: "border-blue-200",
    points: [
      "Full Google Business Profile audit",
      "Website performance and SEO health check",
      "Review and reputation score analysis",
      "Competitor gap mapping — top 3 rivals",
      "Platform listing consistency check",
      "Digital security baseline assessment",
    ],
  },
  {
    phase: "02",
    title: "Build",
    subtitle: "We build every critical touchpoint from the ground up.",
    color: "bg-emerald-600",
    textColor: "text-emerald-600",
    borderColor: "border-emerald-200",
    points: [
      "Professional website design and launch",
      "Optimised Google Business Profile setup",
      "Directory submissions across 10–25+ platforms",
      "Review generation funnel setup",
      "WhatsApp Business profile and automation",
      "Social media profiles created and branded",
    ],
  },
  {
    phase: "03",
    title: "Manage",
    subtitle: "We maintain and grow your presence month after month.",
    color: "bg-violet-600",
    textColor: "text-violet-600",
    borderColor: "border-violet-200",
    points: [
      "Monthly GBP posts and photo updates",
      "Social media content calendar and posting",
      "Ongoing review monitoring and responses",
      "WhatsApp and email re-engagement campaigns",
      "Monthly performance reports",
      "Continuous SEO improvements",
    ],
  },
];

const DIFFERENTIATORS = [
  {
    icon: Target,
    title: "CAS System",
    desc: "Structured, repeatable methodology. Consistent results regardless of who executes each task.",
  },
  {
    icon: Shield,
    title: "Cybersecurity Layer",
    desc: "No other local agency in NCR combines digital marketing with real security expertise.",
  },
  {
    icon: MapPin,
    title: "NCR Local Focus",
    desc: "Deep knowledge of local search behaviour and competitor dynamics that national agencies miss.",
  },
  {
    icon: Users,
    title: "Clinic Specialisation",
    desc: "Vertical expertise means faster results and more relevant strategy for healthcare clients.",
  },
  {
    icon: BarChart3,
    title: "Transparent Process",
    desc: "Monthly reports and direct WhatsApp access — no black box, no guesswork.",
  },
  {
    icon: Zap,
    title: "End-to-End Ownership",
    desc: "Audit, build, manage — all under one roof. You get one accountable partner, not three vendors.",
  },
];

const STARTER_FEATURES = [
  { label: "Website", value: "Up to 5 pages" },
  { label: "Directory Submissions", value: "10 platforms" },
  { label: "Social Posts", value: "Posts & Reels/month" },
  { label: "GBP Management", value: "✓ Included" },
  { label: "Review Funnel", value: "Basic setup" },
  { label: "WhatsApp Marketing", value: "Setup only" },
  { label: "SEO", value: "Basic" },
  { label: "Ad Management", value: "✓ Included" },
  { label: "Reporting", value: "Basic report" },
  { label: "Security Audit", value: "Baseline" },
];

const GROWTH_FEATURES = [
  { label: "Website", value: "Premium + Booking" },
  { label: "Directory Submissions", value: "25+ platforms" },
  { label: "Social Media Management", value: "Full management" },
  { label: "GBP Management", value: "✓ Included" },
  { label: "Review Funnel", value: "Full funnel" },
  { label: "WhatsApp/Email Marketing", value: "Campaigns included" },
  { label: "SEO", value: "Advanced ongoing" },
  { label: "Ad Management", value: "✓ Included" },
  { label: "Reporting", value: "Detailed dashboard" },
  { label: "Security Audit", value: "Full audit" },
];

const TESTIMONIALS = [
  {
    name: "Dr. Priya Sharma",
    role: "Dermatologist, Noida",
    text: "Within 3 months, my clinic went from having no online presence to ranking top 3 on Google Maps in Noida. Patient inquiries doubled. SafeGrow genuinely understands what clinics need.",
    rating: 5,
  },
  {
    name: "Rajesh Gupta",
    role: "CA Firm Owner, Gurgaon",
    text: "I was skeptical at first — I'd worked with agencies before who promised everything and delivered nothing. SafeGrow was different. Monthly reports, WhatsApp access, real results.",
    rating: 5,
  },
  {
    name: "Dr. Amit Verma",
    role: "Physiotherapist, Delhi",
    text: "The review management system alone changed my business. We went from 12 reviews to 90+ reviews in 6 months. New patients mention Google all the time now.",
    rating: 5,
  },
];

function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-18">
          <a href="#" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <span
              className={`font-bold text-xl tracking-tight ${
                scrolled ? "text-gray-900" : "text-white"
              }`}
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Safe<span className="text-cyan-400">Grow</span>
            </span>
          </a>

          <div className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-cyan-400 ${
                  scrolled ? "text-gray-600" : "text-white/90"
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-3">
            <a
              href="#contact"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Get Free Audit
            </a>
          </div>

          <button
            onClick={() => setOpen(!open)}
            className={`lg:hidden p-2 rounded-lg ${scrolled ? "text-gray-700" : "text-white"}`}
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-white border-t border-gray-100 px-4 py-4 space-y-1">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block py-2.5 px-3 text-gray-700 font-medium text-sm rounded-lg hover:bg-gray-50"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            className="block mt-2 py-2.5 px-3 bg-blue-600 text-white font-semibold text-sm rounded-lg text-center"
          >
            Get Free Audit
          </a>
        </div>
      )}
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="SafeGrow digital agency NCR"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-950/90 via-blue-950/75 to-gray-900/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6">
            <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-white/90 text-sm font-medium">
              NCR's Digital Presence Agency — Noida · Gurgaon · Delhi
            </span>
          </div>

          <h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Your Business Deserves to{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
              Be Found Online
            </span>
          </h1>

          <p className="text-lg text-white/75 leading-relaxed mb-10 max-w-2xl">
            We help clinics and small businesses in NCR build a complete digital presence — from Google rankings
            to 5-star reviews to a website that actually converts. Backed by cybersecurity expertise.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-all hover:shadow-lg hover:shadow-blue-500/25 text-base"
            >
              Get Your Free Audit
              <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#how-it-works"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-white/10 backdrop-blur-sm hover:bg-white/20 border border-white/30 text-white font-semibold rounded-xl transition-all text-base"
            >
              See How It Works
            </a>
          </div>

          <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-6">
            {STATS.map((s) => (
              <div key={s.label}>
                <div
                  className="text-3xl font-bold text-white"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  {s.value}
                </div>
                <div className="text-white/60 text-sm mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 hover:text-white transition-colors animate-bounce"
      >
        <ChevronDown className="w-6 h-6" />
      </a>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <Award className="w-4 h-4" />
              Who We Are
            </div>
            <h2
              className="text-3xl lg:text-4xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Built for Local Businesses That Can't Afford to Be Invisible
            </h2>
            <p className="text-gray-600 leading-relaxed mb-5">
              SafeGrow was founded to fix a problem we saw everywhere in NCR — clinics and small businesses
              with genuinely great services but zero online presence. Patients searching for them on Google
              were finding their competitors instead.
            </p>
            <p className="text-gray-600 leading-relaxed mb-5">
              What makes us different is simple: we combine digital growth with cybersecurity protection.
              Our team has ethical hacking expertise, which means we don't just build your online presence —
              we make sure it stays safe and yours.
            </p>
            <p className="text-gray-600 leading-relaxed mb-8">
              We work exclusively in NCR, which gives us a depth of local market knowledge that national
              agencies simply cannot match. We know what patients in Noida search for. We know who your
              competitors are. We know what works here.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "Noida", desc: "Primary market" },
                { label: "Gurgaon", desc: "Growing presence" },
                { label: "Delhi", desc: "Full coverage" },
                { label: "NCR", desc: "Local specialists" },
              ].map((item) => (
                <div key={item.label} className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">{item.label}</div>
                    <div className="text-gray-500 text-xs mt-0.5">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/images/team-work.jpg"
                alt="SafeGrow team working on digital marketing"
                className="w-full h-96 object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-5 border border-gray-100 max-w-xs">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Shield className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900 text-sm">Security-First Agency</div>
                  <div className="text-gray-500 text-xs">Ethical hacking expertise</div>
                </div>
              </div>
              <p className="text-xs text-gray-600">
                The only NCR agency combining digital marketing with real cybersecurity protection.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <Zap className="w-4 h-4" />
            What We Do
          </div>
          <h2
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Every Service Your Business Needs, Under One Roof
          </h2>
          <p className="text-gray-600 leading-relaxed">
            All services are delivered within our CAS framework — audit first, build second, manage ongoing.
            No skipping steps, no guesswork.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group"
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}
                >
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2 text-base">{service.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{service.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-violet-50 text-violet-700 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <Target className="w-4 h-4" />
            The CAS Formula
          </div>
          <h2
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Our Proprietary 3-Phase Methodology
          </h2>
          <p className="text-gray-600 leading-relaxed">
            The CAS Formula is the backbone of every client engagement. Three phases, executed in order,
            every time — because consistent process creates consistent results.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {CAS_PHASES.map((phase, i) => (
            <div key={phase.title} className="relative">
              {i < 2 && (
                <div className="hidden lg:block absolute top-10 right-0 w-8 h-0.5 bg-gray-200 translate-x-4 z-10" />
              )}
              <div className={`rounded-2xl border-2 ${phase.borderColor} bg-white p-7 h-full`}>
                <div className="flex items-center gap-4 mb-5">
                  <div
                    className={`${phase.color} text-white text-sm font-bold px-3 py-1.5 rounded-lg tracking-wider`}
                  >
                    Phase {phase.phase}
                  </div>
                  <h3
                    className="text-xl font-bold text-gray-900"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {phase.title}
                  </h3>
                </div>
                <p className={`text-sm ${phase.textColor} font-medium mb-5`}>{phase.subtitle}</p>
                <ul className="space-y-3">
                  {phase.points.map((point) => (
                    <li key={point} className="flex items-start gap-2.5 text-sm text-gray-600">
                      <CheckCircle className={`w-4 h-4 ${phase.textColor} mt-0.5 flex-shrink-0`} />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="rounded-2xl overflow-hidden shadow-xl">
            <img
              src="/images/seo-growth.jpg"
              alt="SEO growth and local search ranking"
              className="w-full h-80 object-cover"
            />
          </div>
          <div>
            <h3
              className="text-2xl font-bold text-gray-900 mb-4"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Why the Sequence Matters
            </h3>
            <p className="text-gray-600 leading-relaxed mb-5">
              Most agencies skip straight to building — launching a website or running ads without understanding
              what actually exists, what's broken, or who the real competitors are. That's how you waste money.
            </p>
            <p className="text-gray-600 leading-relaxed mb-5">
              Our audit phase ensures every decision we make in the build phase is grounded in data. And the
              manage phase ensures the work compounds over time — not just a one-off spike.
            </p>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 text-blue-600 font-semibold hover:text-blue-700 transition-colors"
            >
              Start with a free audit
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhyUs() {
  return (
    <section className="py-24 bg-gray-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-white/10 text-cyan-400 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <Shield className="w-4 h-4" />
            Why SafeGrow
          </div>
          <h2
            className="text-3xl lg:text-4xl font-bold text-white mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Makes Us Different from Every Other Agency
          </h2>
          <p className="text-white/60 leading-relaxed">
            There are hundreds of digital agencies in NCR. Here's what separates us from the ones who'll
            take your money and disappear.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {DIFFERENTIATORS.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition-all duration-300"
              >
                <div className="w-11 h-11 bg-blue-600/20 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5 text-cyan-400" />
                </div>
                <h3 className="font-bold text-white mb-2">{item.title}</h3>
                <p className="text-white/55 text-sm leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-16 grid lg:grid-cols-2 gap-8">
          <div className="rounded-2xl overflow-hidden">
            <img
              src="/images/security.jpg"
              alt="Digital security for local businesses"
              className="w-full h-64 object-cover rounded-2xl"
            />
          </div>
          <div className="rounded-2xl overflow-hidden">
            <img
              src="/images/clinic-digital.jpg"
              alt="Clinic digital presence management"
              className="w-full h-64 object-cover rounded-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <BarChart3 className="w-4 h-4" />
            Pricing Plans
          </div>
          <h2
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Two Plans. Both Built on the Full CAS Formula.
          </h2>
          <p className="text-gray-600 leading-relaxed">
            Pricing reflects scope, platforms managed, content volume, and depth of optimisation. Final pricing
            is confirmed after the Phase 1 audit.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Starter */}
          <div className="border-2 border-gray-200 rounded-2xl p-8">
            <div className="mb-6">
              <div className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Starter</div>
              <div className="flex items-end gap-1 mb-1">
                <span
                  className="text-4xl font-bold text-gray-900"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  ₹19,999
                </span>
                <span className="text-gray-500 mb-1.5 text-sm">– ₹29,999 setup</span>
              </div>
              <div className="text-gray-600 text-sm">
                + ₹9,999 – ₹14,999 <span className="text-gray-400">/month</span>
              </div>
              <p className="text-gray-500 text-sm mt-3 leading-relaxed">
                Perfect for clinics and small businesses getting their digital foundation right for the first time.
              </p>
            </div>

            <a
              href="#contact"
              className="block w-full py-3 px-5 bg-gray-900 hover:bg-gray-800 text-white font-semibold rounded-xl text-center text-sm transition-colors mb-8"
            >
              Get Started — Starter
            </a>

            <div className="space-y-4">
              {STARTER_FEATURES.map((f) => (
                <div
                  key={f.label}
                  className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0"
                >
                  <span className="text-gray-600 text-sm">{f.label}</span>
                  <span className="text-gray-900 font-medium text-sm text-right max-w-[55%]">{f.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Growth */}
          <div className="border-2 border-blue-600 rounded-2xl p-8 relative bg-blue-600 text-white">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-cyan-400 text-gray-900 text-xs font-bold px-4 py-1.5 rounded-full">
              MOST POPULAR
            </div>
            <div className="mb-6">
              <div className="text-sm font-semibold text-blue-200 uppercase tracking-wider mb-2">Growth</div>
              <div className="flex items-end gap-1 mb-1">
                <span
                  className="text-4xl font-bold text-white"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  ₹49,999
                </span>
                <span className="text-blue-200 mb-1.5 text-sm">– ₹99,999 setup</span>
              </div>
              <div className="text-blue-100 text-sm">
                + ₹24,999 – ₹39,999 <span className="text-blue-300">/month</span>
              </div>
              <p className="text-blue-200 text-sm mt-3 leading-relaxed">
                For businesses serious about dominating local search and turning their online presence into a
                consistent patient pipeline.
              </p>
            </div>

            <a
              href="#contact"
              className="block w-full py-3 px-5 bg-white hover:bg-gray-50 text-blue-600 font-semibold rounded-xl text-center text-sm transition-colors mb-8"
            >
              Get Started — Growth
            </a>

            <div className="space-y-4">
              {GROWTH_FEATURES.map((f) => (
                <div
                  key={f.label}
                  className="flex items-center justify-between py-3 border-b border-blue-500/40 last:border-0"
                >
                  <span className="text-blue-100 text-sm">{f.label}</span>
                  <span className="text-white font-medium text-sm text-right max-w-[55%]">{f.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <p className="text-center text-gray-400 text-sm mt-8">
          Pricing ranges vary based on business size, number of locations, and current digital presence.
          Everything is confirmed after the free Phase 1 audit.
        </p>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-yellow-50 text-yellow-700 rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <Star className="w-4 h-4" />
            Client Stories
          </div>
          <h2
            className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Our Clients Say
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="bg-white rounded-2xl p-7 border border-gray-100 shadow-sm"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 text-sm leading-relaxed mb-6 italic">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-700 font-bold text-sm">{t.name[0]}</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                  <div className="text-gray-500 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-2xl overflow-hidden">
          <img
            src="/images/reviews.jpg"
            alt="Happy clients with 5-star reviews"
            className="w-full h-64 object-cover object-center"
          />
        </div>
      </div>
    </section>
  );
}

function TargetMarket() {
  const segments = [
    {
      icon: "🏥",
      title: "Dental Clinics",
      desc: "High patient LTV. Google Maps is where patients choose their dentist.",
    },
    {
      icon: "🧘",
      title: "Physiotherapy",
      desc: "Review-driven decisions. A strong online presence fills appointment slots.",
    },
    {
      icon: "👨‍⚕️",
      title: "General Practice",
      desc: "Trust is everything. Reviews and GBP visibility drive new patient acquisition.",
    },
    {
      icon: "💆",
      title: "Dermatology & Specialist",
      desc: "Competitive verticals where local SEO is the clearest differentiator.",
    },
    {
      icon: "📊",
      title: "CA & Legal Firms",
      desc: "Offline-first businesses that are digitally underserved but trust-dependent.",
    },
    {
      icon: "🏪",
      title: "Local Retail & Kirana",
      desc: "High foot traffic potential hidden behind zero digital visibility.",
    },
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <Users className="w-4 h-4" />
              Who We Work With
            </div>
            <h2
              className="text-3xl lg:text-4xl font-bold text-gray-900 leading-tight mb-6"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Built for NCR's Offline-First Businesses Going Digital
            </h2>
            <p className="text-gray-600 leading-relaxed mb-8">
              Our primary focus is healthcare — clinics, doctors, and specialist practices where a patient
              retained is worth thousands over their lifetime, and where most owners are too busy to manage
              their own digital presence. We also work with CA firms, legal offices, and local retail.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {segments.map((s) => (
                <div
                  key={s.title}
                  className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div className="text-2xl mb-2">{s.icon}</div>
                  <div className="font-semibold text-gray-900 text-sm mb-1">{s.title}</div>
                  <div className="text-gray-500 text-xs leading-relaxed">{s.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-950 rounded-3xl p-8 text-white">
            <h3
              className="text-xl font-bold mb-6"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Why Clinics Are Our Core Market
            </h3>
            <div className="space-y-5">
              {[
                {
                  icon: "💰",
                  title: "High Lifetime Value",
                  desc: "A retained patient is worth thousands over their lifetime — making digital investment high-ROI.",
                },
                {
                  icon: "🔍",
                  title: "Underserved by Tech",
                  desc: "Most clinic owners are too busy running their practice to manage Google, reviews, and social.",
                },
                {
                  icon: "⭐",
                  title: "Trust-Based Decisions",
                  desc: "Patients choose clinics based on reviews, search rank, and online credibility — all things we control.",
                },
                {
                  icon: "📈",
                  title: "Low Competition Online",
                  desc: "Most NCR clinics have weak or missing GBPs. Clear, low-hanging fruit for rapid improvement.",
                },
              ].map((item) => (
                <div key={item.title} className="flex gap-4">
                  <div className="text-xl mt-0.5">{item.icon}</div>
                  <div>
                    <div className="font-semibold text-white text-sm mb-1">{item.title}</div>
                    <div className="text-white/55 text-sm leading-relaxed">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <MessageCircle className="w-4 h-4" />
              Get in Touch
            </div>
            <h2
              className="text-3xl lg:text-4xl font-bold text-gray-900 mb-5"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Start with a Free Audit. No Commitment.
            </h2>
            <p className="text-gray-600 leading-relaxed mb-8">
              Tell us about your business and we'll show you exactly where you stand online — what's working,
              what's broken, and what your competitors are doing that you're not. It's free, specific, and takes
              less than 24 hours.
            </p>

            <div className="space-y-5">
              <a
                href="https://wa.me/919873002113"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-5 bg-green-50 border border-green-200 rounded-2xl hover:bg-green-100 transition-colors group"
              >
                <div className="w-11 h-11 bg-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-xs text-green-600 font-medium mb-0.5">Fastest Response</div>
                  <div className="font-semibold text-gray-900">WhatsApp Us</div>
                  <div className="text-gray-600 text-sm">+91 98730 02113</div>
                </div>
                <ArrowRight className="w-5 h-5 text-green-600 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="tel:+919873002113"
                className="flex items-center gap-4 p-5 bg-blue-50 border border-blue-200 rounded-2xl hover:bg-blue-100 transition-colors group"
              >
                <div className="w-11 h-11 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-xs text-blue-600 font-medium mb-0.5">Call Us</div>
                  <div className="font-semibold text-gray-900">Phone</div>
                  <div className="text-gray-600 text-sm">+91 98730 02113</div>
                </div>
                <ArrowRight className="w-5 h-5 text-blue-600 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="mailto:safegrow.ncr@gmail.com"
                className="flex items-center gap-4 p-5 bg-gray-100 border border-gray-200 rounded-2xl hover:bg-gray-200 transition-colors group"
              >
                <div className="w-11 h-11 bg-gray-700 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-xs text-gray-500 font-medium mb-0.5">Email</div>
                  <div className="font-semibold text-gray-900">safegrow.ncr@gmail.com</div>
                </div>
                <ArrowRight className="w-5 h-5 text-gray-600 group-hover:translate-x-1 transition-transform" />
              </a>

              <div className="flex items-center gap-4 p-5 bg-gray-50 border border-gray-200 rounded-2xl">
                <div className="w-11 h-11 bg-gray-200 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Service Area</div>
                  <div className="text-gray-600 text-sm">Noida · Gurgaon · Delhi — NCR, India</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-900 text-xl mb-1" style={{ fontFamily: "Sora, sans-serif" }}>
              Request Your Free Audit
            </h3>
            <p className="text-gray-500 text-sm mb-6">We'll review your online presence and get back within 24 hours.</p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                window.open(
                  `https://wa.me/919873002113?text=Hi SafeGrow! I'd like to request a free digital audit for my business.`,
                  "_blank"
                );
              }}
              className="space-y-4"
            >
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Dr. Sharma"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 98xxxxxxxx"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Business Name</label>
                <input
                  type="text"
                  required
                  placeholder="Your Clinic / Business name"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Business Type</label>
                <select
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-600"
                >
                  <option value="">Select your business type</option>
                  <option>Dental Clinic</option>
                  <option>Physiotherapy Clinic</option>
                  <option>General Practice</option>
                  <option>Dermatology / Specialist</option>
                  <option>CA / Legal Firm</option>
                  <option>Retail / Kirana Store</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Your Location in NCR</label>
                <input
                  type="text"
                  placeholder="e.g. Sector 62, Noida"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Anything specific you want help with?</label>
                <textarea
                  rows={3}
                  placeholder="e.g. We don't show up on Google Maps, we have very few reviews..."
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-colors text-sm flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                Send via WhatsApp — Get Free Audit
              </button>

              <p className="text-xs text-gray-400 text-center">
                No spam. No commitment. We respond within 24 hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-950 text-white py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-10 mb-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <span
                className="font-bold text-xl tracking-tight"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                Safe<span className="text-cyan-400">Grow</span>
              </span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed max-w-xs">
              Digital presence agency for clinics and small businesses in NCR. We audit, build, and manage
              your entire online presence — backed by cybersecurity expertise.
            </p>
            <div className="flex gap-3 mt-5">
              <a
                href="https://wa.me/919873002113"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-white/10 hover:bg-green-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <a
                href="mailto:safegrow.ncr@gmail.com"
                className="w-9 h-9 bg-white/10 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <Mail className="w-4 h-4" />
              </a>
              <a
                href="tel:+919873002113"
                className="w-9 h-9 bg-white/10 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <div className="text-white font-semibold text-sm mb-4">Services</div>
            <ul className="space-y-2.5">
              {[
                "Website Design",
                "Google Business Profile",
                "Local SEO",
                "Social Media",
                "Review Management",
                "WhatsApp Marketing",
                "Ad Management",
                "Digital Security",
              ].map((s) => (
                <li key={s}>
                  <a href="#services" className="text-white/50 text-sm hover:text-cyan-400 transition-colors">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="text-white font-semibold text-sm mb-4">Contact</div>
            <ul className="space-y-3">
              <li className="flex items-center gap-2.5 text-white/50 text-sm">
                <Phone className="w-4 h-4 flex-shrink-0" />
                +91 98730 02113
              </li>
              <li className="flex items-center gap-2.5 text-white/50 text-sm">
                <Mail className="w-4 h-4 flex-shrink-0" />
                safegrow.ncr@gmail.com
              </li>
              <li className="flex items-start gap-2.5 text-white/50 text-sm">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                Noida · Gurgaon · Delhi NCR, India
              </li>
            </ul>

            <div className="mt-6 p-4 bg-white/5 rounded-xl border border-white/10">
              <div className="text-xs text-white/40 mb-1">Website</div>
              <div className="text-sm text-cyan-400 font-medium">safegrow.in</div>
              <div className="text-xs text-white/30 mt-1">Coming soon</div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/30 text-xs">
            © 2025 SafeGrow Digital Presence Agency. NCR, India.
          </p>
          <p className="text-white/30 text-xs">
            Noida · Gurgaon · Delhi — Optimise Your Business
          </p>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="font-sans antialiased" style={{ fontFamily: "Inter, sans-serif" }}>
      <Navbar />
      <Hero />
      <About />
      <Services />
      <HowItWorks />
      <WhyUs />
      <Pricing />
      <Testimonials />
      <TargetMarket />
      <Contact />
      <Footer />

      {/* WhatsApp floating button */}
      <a
        href="https://wa.me/919873002113?text=Hi SafeGrow! I'd like to learn more about your services."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-xl hover:shadow-green-500/30 transition-all hover:scale-110"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 text-white" />
      </a>
    </div>
  );
}
